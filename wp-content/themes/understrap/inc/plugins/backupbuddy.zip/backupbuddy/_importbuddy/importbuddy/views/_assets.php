<?php
pb_backupbuddy::load_style( 'style.css' );
pb_backupbuddy::load_style( 'nprogress.css' );
pb_backupbuddy::load_style( 'animate.css' );

pb_backupbuddy::load_script( 'jquery.js' );
pb_backupbuddy::load_script( 'ui.core.js' );
pb_backupbuddy::load_script( 'tooltip.js' );
pb_backupbuddy::load_script( 'nprogress.js' );
pb_backupbuddy::load_script( 'importbuddy.js' );